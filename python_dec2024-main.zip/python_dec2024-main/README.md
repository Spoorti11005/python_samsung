# python_dec2024
This Repositary is created in KLEIT  Samsung Innovation lab which was held in December
