#check for a leap_year
input_year=int(input("Enter a year"))
if(input_year%4==0):
    print(input_year, 'is a leap year')