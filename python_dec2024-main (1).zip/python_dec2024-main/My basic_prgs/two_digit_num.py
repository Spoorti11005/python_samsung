# check number is two digit
input_number=int(input("Enter a digit"))
if(input_number >= 9 and input_number < 100):
    print(input_number,"is a two digit number")