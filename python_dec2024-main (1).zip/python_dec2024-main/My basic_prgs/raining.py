#check for a raining
user_input=("Enter a string")
if ()